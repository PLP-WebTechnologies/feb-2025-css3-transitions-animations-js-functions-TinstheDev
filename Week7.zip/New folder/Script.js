// Check if the user has previously clicked the button by using localStorage
const animateBtn = document.getElementById('animateBtn');

// Check if the animation state is saved in localStorage
if (localStorage.getItem('buttonClicked') === 'true') {
    animateBtn.classList.add('clicked');  // If clicked previously, trigger animation on page load
}

// Add event listener to the button
animateBtn.addEventListener('click', () => {
    // Add the animation class to the button when clicked
    animateBtn.classList.add('clicked');
    
    // Store the user preference in localStorage (the button has been clicked)
    localStorage.setItem('buttonClicked', 'true');
});
